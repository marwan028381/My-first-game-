# معركة الجيتباك — مشروع أندرويد

لعبة الويب نفسها داخل تطبيق أندرويد: ملء الشاشة، بالعرض دائماً، والشاشة لا تنطفئ أثناء اللعب.
ملف اللعبة: app/src/main/assets/index.html

## الطريقة 1: Android Studio (على الحاسوب)
1. ثبّت Android Studio من developer.android.com/studio
2. File > Open ثم اختر مجلد JetSkirmish وانتظر انتهاء المزامنة (Sync).
3. Build > Build Bundle(s) / APK(s) > Build APK(s)
4. ستجد الملف هنا: app/build/outputs/apk/debug/app-debug.apk
5. انقله إلى الهاتف وافتحه (فعّل "التثبيت من مصادر غير معروفة" عند الطلب).

## الطريقة 2: بدون تثبيت أي برنامج (GitHub)
1. أنشئ مستودعاً جديداً على github.com وارفع محتويات هذا المجلد إليه.
2. افتح تبويب Actions وشغّل Build APK (أو ينطلق تلقائياً مع الرفع).
3. بعد دقائق، نزّل app-debug.apk من قسم Artifacts في نتيجة التشغيل.

## ملاحظات
- النسخة المبنية هي debug وتعمل للتثبيت المباشر. لنشرها على Google Play تحتاج نسخة release موقّعة.
- الخطوط (Lalezar وTajawal) تُحمَّل من الإنترنت عند توفره، وبدونه يستخدم الهاتف خطاً عربياً بديلاً.
- لتغيير اسم التطبيق: app/src/main/res/values/strings.xml
